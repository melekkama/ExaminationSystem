﻿using ExaminationSystem.Entities.Concrete;

namespace ExaminationSystem.FormUI.States;

public static class LoginUserState
{
    public static User User { get; set; }
}
