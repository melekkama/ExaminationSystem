﻿using System;

namespace ExaminationSystem.DAL.StringInfos;

public struct SystemUserInfo
{
    public const string SystemUserId = "5b4be8b8-a338-4446-ac09-36864dfdbe8d";
}
