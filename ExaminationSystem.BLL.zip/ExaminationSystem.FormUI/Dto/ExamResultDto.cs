﻿namespace ExaminationSystem.FormUI.Dto;

public class ExamResultDto
{
    public int Total { get; set; }
    public int CorrectCount { get; set; }
}
