﻿using MaterialSkin;
using MaterialSkin.Controls;

namespace ExaminationSystem.FormUI.Services;

public interface IDefaultMaterialFormTheme
{
    MaterialSkinManager UseTheme(MaterialForm form);
}
