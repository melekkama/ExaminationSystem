﻿namespace ExaminationSystem.Entities.Concrete;

public class SigmaDate:EntityBase
{
    public int StepOneDate { get; set; }
    public int StepTwoDate { get; set; }
    public int StepThreeDate { get; set; }
    public int StepFourDate { get; set; }
    public int StepFiveDate { get; set; }
    public int StepSixDate { get; set; }
}
