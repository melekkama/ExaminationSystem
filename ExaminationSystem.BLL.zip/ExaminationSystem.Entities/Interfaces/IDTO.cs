﻿namespace ExaminationSystem.Entities.Interfaces;

public interface IDTO
{
}
