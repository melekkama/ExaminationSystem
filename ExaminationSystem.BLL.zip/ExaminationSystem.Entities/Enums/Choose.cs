﻿namespace ExaminationSystem.Entities.Enums;

public enum Choose
{
    A,
    B,
    C,
    D
}
