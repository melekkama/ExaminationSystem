﻿namespace ExaminationSystem.DAL.StringInfos;

public struct RoleInfo
{
    public const string Admin = "Admin";
    public const string Examiner = "Examiner";
    public const string Student = "Student";
}
